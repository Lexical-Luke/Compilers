char argv;
int daytab [13];
void comp ();
char x [3] [5];
int fun (int a, int j);

