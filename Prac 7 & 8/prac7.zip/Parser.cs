using Library;



using System;
using System.IO;
using System.Text;

namespace Awards {

public class Parser {
	public const int _EOF = 0;
	public const int _name = 1;
	public const int _studentNumber = 2;
	public const int _decnum = 3;
	public const int _eol = 4;
	// terminals
	public const int EOF_SYM = 0;
	public const int name_Sym = 1;
	public const int studentNumber_Sym = 2;
	public const int decnum_Sym = 3;
	public const int eol_Sym = 4;
	public const int S_Sym = 5;
	public const int H_Sym = 6;
	public const int C_Sym = 7;
	public const int E_Sym = 8;
	public const int L_Sym = 9;
	public const int P_Sym = 10;
	public const int NOT_SYM = 11;
	// pragmas

	public const int maxT = 11;

	const bool T = true;
	const bool x = false;
	const int minErrDist = 2;

	public static Token token;    // last recognized token   /* pdt */
	public static Token la;       // lookahead token
	static int errDist = minErrDist;

	static bool
      eligible = true;



	static void SynErr (int n) {
		if (errDist >= minErrDist) Errors.SynErr(la.line, la.col, n);
		errDist = 0;
	}

	public static void SemErr (string msg) {
		if (errDist >= minErrDist) Errors.Error(token.line, token.col, msg); /* pdt */
		errDist = 0;
	}

	public static void SemError (string msg) {
		if (errDist >= minErrDist) Errors.Error(token.line, token.col, msg); /* pdt */
		errDist = 0;
	}

	public static void Warning (string msg) { /* pdt */
		if (errDist >= minErrDist) Errors.Warn(token.line, token.col, msg);
		errDist = 2; //++ 2009/11/04
	}

	public static bool Successful() { /* pdt */
		return Errors.count == 0;
	}

	public static string LexString() { /* pdt */
		return token.val;
	}

	public static string LookAheadString() { /* pdt */
		return la.val;
	}

	static void Get () {
		for (;;) {
			token = la; /* pdt */
			la = Scanner.Scan();
			if (la.kind <= maxT) { ++errDist; break; }

			la = token; /* pdt */
		}
	}

	static void Expect (int n) {
		if (la.kind==n) Get(); else { SynErr(n); }
	}

	static bool StartOf (int s) {
		return set[s, la.kind];
	}

	static void ExpectWeak (int n, int follow) {
		if (la.kind == n) Get();
		else {
			SynErr(n);
			while (!StartOf(follow)) Get();
		}
	}

	static bool WeakSeparator (int n, int syFol, int repFol) {
		bool[] s = new bool[maxT+1];
		if (la.kind == n) { Get(); return true; }
		else if (StartOf(repFol)) return false;
		else {
			for (int i=0; i <= maxT; i++) {
				s[i] = set[syFol, i] || set[repFol, i] || set[0, i];
			}
			SynErr(n);
			while (!s[la.kind]) Get();
			return StartOf(syFol);
		}
	}

	static void Awards() {
		while (la.kind == studentNumber_Sym) {
			eligible = true; string name; float avg;
			StudentNumber();
			FullName(out string name);
			Faculty();
			Credits();
			Avgmark(out float avg);
			while (!(la.kind == EOF_SYM || la.kind == eol_Sym)) {SynErr(12); Get();}
			Expect(eol_Sym);
			if (eligible) IO.writeLine(name, avg );
		}
	}

	static void StudentNumber() {
		int year;
		Expect(studentNumber_Sym);
		string s = token.val.substring(0, 2);
		try {
		  year = Integer.parseInt(s);
		} catch (NumberFormatException e) {
		  year = 0; SemError("number too large");
		}
		if (year <= 18) year = 2000 + year;
		else year = 1900 + year;
		if (2018 - year >= 3) eligible = false;
	}

	static void FullName(string fname) {
		Expect(name_Sym);
		fname = token.val;
		while (la.kind == name_Sym) {
			Get();
			fname = fname + token.val;
		}
	}

	static void Faculty() {
		switch (la.kind) {
		case S_Sym: {
			Get();
			break;
		}
		case H_Sym: {
			Get();
			break;
		}
		case C_Sym: {
			Get();
			break;
		}
		case E_Sym: {
			Get();
			break;
		}
		case L_Sym: {
			Get();
			break;
		}
		case P_Sym: {
			Get();
			break;
		}
		default: SynErr(13); break;
		}
	}

	static void Credits() {
		Expect(decnum_Sym);
		if (token.val < 18.0) eligible = false;
	}

	static void Avgmark(float average) {
		Expect(decnum_Sym);
		average = token.val;
		if (average < 75.0) eligible = false;
	}



	public static void Parse() {
		la = new Token();
		la.val = "";
		Get();
		Awards();
		Expect(EOF_SYM);

	}

	static bool[,] set = {
		{T,x,x,x, T,x,x,x, x,x,x,x, x}

	};

} // end Parser

/* pdt - considerable extension from here on */

public class ErrorRec {
	public int line, col, num;
	public string str;
	public ErrorRec next;

	public ErrorRec(int l, int c, string s) {
		line = l; col = c; str = s; next = null;
	}

} // end ErrorRec

public class Errors {

	public static int count = 0;                                     // number of errors detected
	public static int warns = 0;                                     // number of warnings detected
	public static string errMsgFormat = "file {0} : ({1}, {2}) {3}"; // 0=file 1=line, 2=column, 3=text
	static string fileName = "";
	static string listName = "";
	static bool mergeErrors = false;
	static StreamWriter mergedList;

	static ErrorRec first = null, last;
	static bool eof = false;

	static string GetLine() {
		char ch, CR = '\r', LF = '\n';
		int l = 0;
		StringBuilder s = new StringBuilder();
		ch = (char) Buffer.Read();
		while (ch != Buffer.EOF && ch != CR && ch != LF) {
			s.Append(ch); l++; ch = (char) Buffer.Read();
		}
		eof = (l == 0 && ch == Buffer.EOF);
		if (ch == CR) {  // check for MS-DOS
			ch = (char) Buffer.Read();
			if (ch != LF && ch != Buffer.EOF) Buffer.Pos--;
		}
		return s.ToString();
	}

	static void Display (string s, ErrorRec e) {
		mergedList.Write("**** ");
		for (int c = 1; c < e.col; c++)
			if (s[c-1] == '\t') mergedList.Write("\t"); else mergedList.Write(" ");
		mergedList.WriteLine("^ " + e.str);
	}

	public static void Init (string fn, string dir, bool merge) {
		fileName = fn;
		listName = dir + "listing.txt";
		mergeErrors = merge;
		if (mergeErrors)
			try {
				mergedList = new StreamWriter(new FileStream(listName, FileMode.Create));
			} catch (IOException) {
				Errors.Exception("-- could not open " + listName);
			}
	}

	public static void Summarize () {
		if (mergeErrors) {
			mergedList.WriteLine();
			ErrorRec cur = first;
			Buffer.Pos = 0;
			int lnr = 1;
			string s = GetLine();
			while (!eof) {
				mergedList.WriteLine("{0,4} {1}", lnr, s);
				while (cur != null && cur.line == lnr) {
					Display(s, cur); cur = cur.next;
				}
				lnr++; s = GetLine();
			}
			if (cur != null) {
				mergedList.WriteLine("{0,4}", lnr);
				while (cur != null) {
					Display(s, cur); cur = cur.next;
				}
			}
			mergedList.WriteLine();
			mergedList.WriteLine(count + " errors detected");
			if (warns > 0) mergedList.WriteLine(warns + " warnings detected");
			mergedList.Close();
		}
		switch (count) {
			case 0 : Console.WriteLine("Parsed correctly"); break;
			case 1 : Console.WriteLine("1 error detected"); break;
			default: Console.WriteLine(count + " errors detected"); break;
		}
		if (warns > 0) Console.WriteLine(warns + " warnings detected");
		if ((count > 0 || warns > 0) && mergeErrors) Console.WriteLine("see " + listName);
	}

	public static void StoreError (int line, int col, string s) {
		if (mergeErrors) {
			ErrorRec latest = new ErrorRec(line, col, s);
			if (first == null) first = latest; else last.next = latest;
			last = latest;
		} else Console.WriteLine(errMsgFormat, fileName, line, col, s);
	}

	public static void SynErr (int line, int col, int n) {
		string s;
		switch (n) {
			case 0: s = "EOF expected"; break;
			case 1: s = "name expected"; break;
			case 2: s = "studentNumber expected"; break;
			case 3: s = "decnum expected"; break;
			case 4: s = "eol expected"; break;
			case 5: s = "\"S\" expected"; break;
			case 6: s = "\"H\" expected"; break;
			case 7: s = "\"C\" expected"; break;
			case 8: s = "\"E\" expected"; break;
			case 9: s = "\"L\" expected"; break;
			case 10: s = "\"P\" expected"; break;
			case 11: s = "??? expected"; break;
			case 12: s = "this symbol not expected in Awards"; break;
			case 13: s = "invalid Faculty"; break;

			default: s = "error " + n; break;
		}
		StoreError(line, col, s);
		count++;
	}

	public static void SemErr (int line, int col, int n) {
		StoreError(line, col, ("error " + n));
		count++;
	}

	public static void Error (int line, int col, string s) {
		StoreError(line, col, s);
		count++;
	}

	public static void Error (string s) {
		if (mergeErrors) mergedList.WriteLine(s); else Console.WriteLine(s);
		count++;
	}

	public static void Warn (int line, int col, string s) {
		StoreError(line, col, s);
		warns++;
	}

	public static void Warn (string s) {
		if (mergeErrors) mergedList.WriteLine(s); else Console.WriteLine(s);
		warns++;
	}

	public static void Exception (string s) {
		Console.WriteLine(s);
		System.Environment.Exit(1);
	}

} // end Errors

} // end namespace
